# RL Trader — Backend (FastAPI, Docker) + Netlify Dashboard

## Easiest deploy (no local installs)
1) Create a **GitHub repo**, upload this folder structure.
2) **Backend on Render (or Railway)**:
   - New Web Service → root = `backend/` (it auto-detects the Dockerfile).
   - Env vars:
     - `API_KEY` = long random string.
     - `CORS_ORIGIN` = `https://<your-netlify>.netlify.app` (or `*` to test).
   - Add a persistent disk mounted at `/data` (for SQLite + model).
   - Deploy → note the URL, e.g. `https://your-backend.onrender.com`.
3) **Netlify**:
   - New site from Git → base directory `netlify/`.
   - Publish dir = `netlify/site`, Functions dir = `netlify/functions`.
   - Env vars:
     - `API_BASE_URL` = your Render URL.
     - `API_KEY` = SAME as backend.
   - Deploy → open your Netlify URL.

## What you get
- Paper-trading live during market hours; nightly PPO training off-hours.
- Netlify dashboard with charts + ultra-verbose trade history.
- No CSV/PNG saved; only model + SQLite DB on the backend disk.

## Safety
- Paper-only. API is read-only behind a Bearer token. CORS limited to your Netlify origin.